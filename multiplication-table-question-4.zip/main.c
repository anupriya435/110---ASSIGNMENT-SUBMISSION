/******************************************************************************

programme done by anupriya -A2305220110
multiplication table

*******************************************************************************/
#include <stdio.h>

int main()
{int i ,n;
    printf("enter the number");
    scanf("%d",&n);
    printf("multiple of %d \n",n);
    for(i=1;i<=10;i++)
     {printf("%d X %d = %d \n",n,i,i*n);
     }
    return 0;
}

