/******************************************************************************

programme done by anupriya -A2305220110
print the first and last digit of a number

*******************************************************************************/
#include <stdio.h>
#include <math.h>

int main()
{int n,d,last,first;

    printf("enter the number");
    scanf("%d",&n);
    last=n%10;                                     /*last digit==> n=n%10 */
    printf("LAST DIGIT : %d \n",last);
    d=(int)log10(n)+1;   
     printf("number of digits %d\n",d);                 /*if n number has d digits then ==>*/
     first=(int)(n/pow(10,d-1));                /*(10^d-1) <= n < (10^d)   (10^d will always have one extra digit to the given number)*/
     printf("FIRST DIGIT : %d\n",first);         /*(d-1) <= log10(n) < d    (if we ignore the right hand side)*/
    return 0;                                 /*    d =log10(n) +1    */
    }                                        /*    d=log10(n)+1    */
                                            /*   first digit=(n/pow(10,d-1))    */
   


