/******************************************************************************

programme done by anupriya -A2305220110
count of each number or frequency of each number

*******************************************************************************/
#include <stdio.h>

int main()
{int count[10],i,n,l,num;

    printf("NUMBER enter  :");
    scanf("%d",&num);
    for(i=0;i<10;i++)
    count[i]=0;
    n=num;
    while(n!=0)
    {l=(int)n%10;
    n=(int)n/10;
    count[l]++;
    }
    for(i=0;i<10;i++)
    printf("\nfrequency of %d  is %d\n",i,count[i]);
    

    return 0;
}

