/******************************************************************************

programme done by anupriya -A2305220110
count the number of digits in a number

*******************************************************************************/
#include <stdio.h>
#include<math.h>

int main()
{int n,count=0;
    printf("enter the number");
    scanf("%d",&n);
  count=(int)log10(n)+1;
    printf("no of digits %d",count);
    return 0;
}



