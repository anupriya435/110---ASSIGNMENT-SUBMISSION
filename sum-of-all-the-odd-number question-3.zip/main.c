/******************************************************************************
programme done by anupriya -A2305220110
sum of all odd nnumbers

*******************************************************************************/
#include <stdio.h>

int main()
{int i,n,sum=0;
printf("enter the number range");
scanf("%d",&n);
for(i=1;i<=n;i++)
{if((i%2)!=0)
{sum+=i;
}
else
continue;
}
printf("%d",sum);
    return 0;
}


