/******************************************************************************

programme done by anupriya -A2305220110
ASCII CODE for all the characters.

*******************************************************************************/
#include <stdio.h>

int main()
{ int i;
   for(i=0;i<=255;i++)
   printf("\n the ASCII value of character %cis:%d \n",i,i);

    return 0;
}


