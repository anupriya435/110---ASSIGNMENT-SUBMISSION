/******************************************************************************

programme done by anupriya -A2305220110
swap the first and last digit of a number
*******************************************************************************/

#include <stdio.h>

#include<math.h>

int main ()
{
  int f, l, c, n, d, swapnum,a,b;
  printf ("enter the number ");
  scanf ("%d", &n);
  printf ("\t\tORIGINAL LAST AND FIRST POSITION NUMBER:\n");
  l = n % 10;
  printf ("--->LAST DIGIT %d \n", l);
  d = (int) log10 (n) + 1;
  f = (int) (n / (pow (10, d - 1)));
  printf ("--->FIRST DIGIT %d \n", f);
  c = f;
  f = l;
  l = c;
  printf ("\t\tNEW VALUES of LAST AND FIRST POSITION NUMBER \n");
  printf ("--->LAST DIGIT %d \n", l);
  printf ("--->FIRST DIGIT %d \n", f);  
  
a=l*pow(10,d-1);
b=n%a;
n=b/10;
 swapnum=f*(pow(10,d-1))+(n*10)+l;
   printf ("\t\tSWAPPED NEW NUMBER \n");
   printf ("swapped number %d \n", swapnum);
  return 0;
}


